package com.simplilearn.softmax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftmaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
